function funk=compute_Jgamma_funval(yk,psivec,diagM,K,gamma)
gk=yk-psivec;
f1=1/2*yk'*(K*yk);
f2=sum(diagM.*(min(0,gk)).^2)/2/gamma;
funk=f1+f2;
