function [yk,stepsizek,DJyk,funk]=pgd_find_step(stepsizek,yk,psivec,K,diagM,gamma,funk,DJyk)
% firstly compute gradient
ndec=length(diagM);
ytemp=yk-stepsizek*DJyk;
funtemp=compute_Jgamma_funval(ytemp,psivec,diagM,K,gamma);
flag=((funtemp-funk)<=-1e-4/stepsizek*sum((ytemp-yk).^2.*diagM));
eta1=2; eta2=0.4;
if flag
   % add stepsize
   for iter=1:50
       stepsizek=stepsizek*eta1;
       ytemp1=yk-stepsizek*DJyk;
       funtemp1=compute_Jgamma_funval(ytemp1,psivec,diagM,K,gamma);
       if ((funtemp1-funk)<=-1e-4/stepsizek*sum((ytemp1-yk).^2.*diagM)) && stepsizek<=1e2
           ytemp=ytemp1;
           funtemp=funtemp1;
       else
           yk=ytemp;       
           funk=funtemp;
           stepsizek=stepsizek/eta1;
           break
       end
   end
else 
   % reduce stepsize 
    for iter=1:50
       stepsizek=stepsizek*eta2;
       ytemp=yk-stepsizek*DJyk;
       funtemp=compute_Jgamma_funval(ytemp,psivec,diagM,K,gamma);
       if ((funtemp-funk)<=-1e-4/stepsizek*sum((ytemp-yk).^2.*diagM)) || (stepsizek<=1e-5)
           yk=ytemp;
           funk=funtemp;
           if stepsizek<=1e-5
              stepsizek=stepsizek*eta1*1.5;
           end
           break
       end
   end 
end
DJyk=compute_gradient_Jgamma(yk,psivec,K,diagM,gamma);
%{
for iter=1:10
   utemp=min(ub,max(ua,uk-stepsizek*DJuk));
   ytemp=state_solver(K,diagM,utemp,yk,ndec);
   funtemp=compute_Jgamma_funval(ytemp,utemp,ydvec,ycvec,diagM,alpha,gamma);
   if funtemp<=funk-1e-4*sum((utemp-uk).*DJuk.*diagM)%funtemp<=funk-1e-4/stepsizek*sum((utemp-uk).^2.*diagM)
       funk=funtemp;
       yk=ytemp;
       uk=utemp;
       DJuk=compute_gradient_Jgamma(yk,uk,ydvec,ycvec,K,diagM,alpha,gamma);
       break
   else
       stepsizek=stepsizek/2;
   end
end
%}