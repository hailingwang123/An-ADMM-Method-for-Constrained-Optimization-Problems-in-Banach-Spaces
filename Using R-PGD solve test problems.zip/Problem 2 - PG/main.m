% Using regularizard-PGM 
% Example 1 -- semilinear PDE optimal control problem 
left=0; right=1;
bottom=0; top=1;
h=1/2^5;
Nx=(right-left)/h+1;
ndec=(Nx-2)^2;
basis_type=201;
[P,T]=generate_PT(left,right,bottom,top,h,basis_type);
boundary_nodes=generate_boundarynodes(left,right,bottom,top,h,basis_type);
boundary_nodes(1,:)=[];
[coeff_ref,intpt_ref]=generate_Guass_Ref(4);
M=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,0],[0,0]);
K1=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[1,0],[1,0]);
K2=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,1],[0,1]);
K=K1+K2;
% mass lumping technique
M=spdiags(M*ones(Nx^2,1),0,Nx^2,Nx^2);
M(boundary_nodes,:)=[]; M(:,boundary_nodes)=[];
K(boundary_nodes,:)=[]; K(:,boundary_nodes)=[];
diagM=diag(M);
% yt=state_solver(K,diagM,randn(ndec,1),zeros(ndec,1),ndec);
ydvec=-ones(ndec,1);
ycvec=zeros(Nx^2,1);
for i=1:Nx^2
   vec=P(:,i);
   ycvec(i)=ycfun(vec(1),vec(2));
end
yc=ycvec;
ycvec(boundary_nodes)=[];
% control bounds
ua=-10; ub=10;
%% regularized-projection gradient descent solver
uk=zeros(ndec,1); 
yk=zeros(ndec,1); 
alpha=1e-3; 
iter_PG=[];  
tic
tol_approx=1e-6;
print_yes=0;
if print_yes
   fprintf('\n  iter| etap|  gamma  stepk');
end
for iter_outer=1:20
   gamma=10^(-2*iter_outer);
   % using PGM approach inner subproblem P^{\gamma}
   stepsizek=1;
   DJuk=compute_gradient_Jgamma(yk,uk,ydvec,ycvec,K,diagM,alpha,gamma);
   funk=compute_Jgamma_funval(yk,uk,ydvec,ycvec,diagM,alpha,gamma);
   for iter_inner=1:1e6
       % pgd
       [yk,uk,stepsizek,DJuk,funk]=pgd_find_step(stepsizek,yk,uk,ydvec,ycvec,K,diagM,alpha,gamma,ua,ub,funk,DJuk);
       residual=h*norm(uk-max(ua,min(ub,uk-DJuk)));
       if print_yes
          fprintf('\n %5d| %2.1e| %2.1e %2.1e', ...
                 iter_inner, residual,gamma,stepsizek);
       end
       if residual<=1e-6
          iter_PG=[iter_PG,iter_inner];
          break
       end
   end
   gk=yk-ycvec;
   dist2orgprob=h*norm(gk-max(gk,0));
   if dist2orgprob<=tol_approx
       fprintf('\n')
       break
   else
       if print_yes
           fprintf('\n  iter| etau    etaz    etafea|  gamma  stepk');
       end
   end
end
total_time=toc;
%
disyd=h*norm(yk-ydvec);
normu=h*norm(uk);
fprintf('Total Time is %8.2e\n',total_time)
fprintf('Relative distance is %8.2e\n',disyd/(h*norm(ydvec)))
fprintf('The L2 norm of u is %8.2e\n',normu)
fprintf('The objective function value is %8.2e\n',1/2*disyd^2+alpha/2*normu^2)
fprintf('The state constraints violation is %8.2e\n',h*norm(min(yk-ycvec,0)))
fprintf('Total PGD iterations %d, Average PGD %8.2e, Total regularized time %d\n',sum(iter_PG),mean(iter_PG),length(iter_PG))
%% plot results
%{
[X,Y]=meshgrid(left:h:right,bottom:h:top);
decnodes=setdiff(1:Nx^2,boundary_nodes);
Ysol=zeros(Nx^2,1); Usol=Ysol; Lambdasol=Usol; 
Ysol(decnodes)=yk; Usol(decnodes)=uk; Yc=yc; 
figure(1)
s1=surf(X,Y,reshape(Ysol,[],Nx),'FaceAlpha',0.5);
s1.EdgeColor='none';
colormap jet
colorbar
xlabel('x')
ylabel('y')
figure(2)
s2=surf(X,Y,reshape(Usol,[],Nx),'FaceAlpha',0.5);
s2.EdgeColor='none';
colormap jet
colorbar
xlabel('x')
ylabel('y')
figure(3)
s3=surf(X,Y,reshape(Yc,[],Nx),'FaceAlpha',0.5);
s3.EdgeColor='none';
colormap jet
xlabel('x')
ylabel('y')
%}

