% Using regularizard-ADMM for solving optimization problem in Banach spaces
left=0; right=1;
bottom=0; top=1;
h=1/2^4;
Nx=(right-left)/h+1;
psi=@(x,y) max(0.1-0.5*norm([x-0.5,y-0.5]),0);
basis_type=201;
[P,T] = generate_PT(left,right,bottom,top,h,basis_type);
boundary_nodes=generate_boundarynodes(left,right,bottom,top,h,basis_type);
boundary_nodes(1,:)=[];
[coeff_ref,intpt_ref]=generate_Guass_Ref(4);
M=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,0],[0,0]);
K1=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[1,0],[1,0]);
K2=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,1],[0,1]);
K=K1+K2;
decnodes=setdiff(1:Nx^2,boundary_nodes);
Psivec=zeros(Nx^2,1);
% function psi value
for i=1:(Nx-2)^2
   veci=P(:,decnodes(i));
   Psivec(decnodes(i))=psi(veci(1),veci(2));
end
psivec=Psivec(decnodes);
[X,Y]=meshgrid(left:h:right,bottom:h:top);
figure(1)
s1=surf(X,Y,reshape(Psivec,Nx,[]));
s1.EdgeColor='none';
colormap jet
% mass lumping
diagM=M*ones(Nx^2,1);
diagM(boundary_nodes)=[];
K(boundary_nodes,:)=[]; K(:,boundary_nodes)=[];
%% regularizaed-projection gradient descent solver
ndec=length(decnodes);
yk=zeros(ndec,1); 
iter_PG=[];  
tic
tol_approx=1e-5;
print_yes=1;
if print_yes
   fprintf('\n  iter| etap|  gamma  stepk');
end
for iter_outer=1:20
   gamma=10^(-2*iter_outer);
   %beta=1/gamma;
   % using ADMM approach inner subproblem P^{\gamma}
   stepsizek=1;
   DJyk=compute_gradient_Jgamma(yk,psivec,K,diagM,gamma);
   funk=compute_Jgamma_funval(yk,psivec,diagM,K,gamma);
   for iter_inner=1:1e6
       % pgd
       [yk,stepsizek,DJyk,funk]=pgd_find_step(stepsizek*1.1,yk,psivec,K,diagM,gamma,funk,DJyk);
       residual=h*norm(DJyk);
       if print_yes
          fprintf('\n %5d| %2.1e| %2.1e %2.1e', ...
                 iter_inner, residual,gamma,stepsizek);
       end
       if residual<=1e-5
          iter_PG=[iter_PG,iter_inner];
          break
       end
   end
   gk=yk-psivec;
   dist2orgprob=h*norm(gk-max(gk,0));
   if dist2orgprob<=tol_approx
       fprintf('\n')
       break
   else
       if print_yes
           fprintf('\n  iter| etap|  gamma  stepk');
       end
   end
end
total_time=toc;
fprintf('Total Time is %8.2e\n',total_time)
fprintf('The objective function value is %8.2e\n',full(1/2*yk'*(K*yk)))
fprintf('The feasibility violation is %8.2e\n',h*norm(min(yk-psivec,0)))
fprintf('Total PG iterations %d, Average PG %8.2e, Total regularized time %d\n',sum(iter_PG),mean(iter_PG),length(iter_PG))
%% plot results
Yk=zeros(Nx^2,1);
Yk(decnodes)=ykp1;
figure(2)
s2=surf(X,Y,reshape(Yk,[],Nx));
s2.EdgeColor='none';
colormap jet



