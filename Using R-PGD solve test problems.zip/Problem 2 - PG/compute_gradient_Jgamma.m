function DJyk=compute_gradient_Jgamma(yk,psivec,K,diagM,gamma)
DJyk=(K*yk+min(yk-psivec,0)/gamma)./diagM;