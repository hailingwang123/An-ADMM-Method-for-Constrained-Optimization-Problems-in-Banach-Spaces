function [yk,uk,xik,stepsizek,DJuk,DJxik,funk]=pgd_find_step(stepsizek,yk,uk,xik,psivec,P,L,D,diagM,alpha,gamma,funk,DJuk,DJxik)

utemp=min(uk-stepsizek*DJuk,0); xitemp=max(xik-stepsizek*DJxik,0);
ytemp=P*(L'\((1./diag(D)).*(L\(P'*(diagM.*(utemp+xitemp))))));
funtemp=compute_Jgamma_funval(ytemp,utemp,xitemp,psivec,diagM,alpha,gamma);
flag=((funtemp-funk)<=-1e-4/stepsizek*(sum((utemp-uk).^2.*diagM)+sum((xitemp-xik).^2.*diagM)));
eta1=2; eta2=0.4;
if flag
   % add stepsize
   for iter=1:50
       stepsizek=stepsizek*eta1;
       utemp1=min(uk-stepsizek*DJuk,0); xitemp1=max(xik-stepsizek*DJxik,0);
       ytemp1=P*(L'\((1./diag(D)).*(L\(P'*(diagM.*(utemp1+xitemp1))))));
       funtemp1=compute_Jgamma_funval(ytemp1,utemp1,xitemp1,psivec,diagM,alpha,gamma);
       %((Lbetatemp1-Lbeta)<=-1e-4*sum((utemp1-uk).^2.*diagM)) && (norm(utemp1-utemp)>1e-6)
       if ((funtemp1-funk)<=-1e-4/stepsizek*(sum((utemp1-uk).^2.*diagM)+sum((xitemp1-xik).^2.*diagM))) && stepsizek<=100 %&& (norm(utemp1-utemp)>1e-6)
           utemp=utemp1;
           xitemp=xitemp1;
           ytemp=ytemp1;
           funtemp=funtemp1;
       else
           yk=ytemp;
           xik=xitemp;
           uk=utemp;
           funk=funtemp;
           stepsizek=stepsizek/eta1;
           break
       end
   end
else 
   % reduce stepsize 
    for iter=1:50
       stepsizek=stepsizek*eta2;
       utemp=min(uk-stepsizek*DJuk,0); xitemp=max(xik-stepsizek*DJxik,0);
       ytemp=P*(L'\((1./diag(D)).*(L\(P'*(diagM.*(utemp+xitemp))))));
       funtemp=compute_Jgamma_funval(ytemp,utemp,xitemp,psivec,diagM,alpha,gamma);
       if ((funtemp-funk)<=-1e-4/stepsizek*(sum((utemp-uk).^2.*diagM)+sum((xitemp-xik).^2.*diagM)))|| (stepsizek<=1e-4)
           yk=ytemp;
           uk=utemp;
           xik=xitemp;
           funk=funtemp;
           if stepsizek<=1e-4
              stepsizek=stepsizek*eta1*1.5;
           end
           break
       end
   end 
end
[DJuk,DJxik]=compute_gradient_Jgamma(yk,uk,xik,psivec,P,L,D,diagM,alpha,gamma);

