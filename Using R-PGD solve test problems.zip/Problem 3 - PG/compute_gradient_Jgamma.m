function [DJu,DJxi]=compute_gradient_Jgamma(yk,uk,xik,psivec,P,L,D,diagM,alpha,gamma)
g2=sum((psivec-yk).*diagM.*xik);
rhsk=yk-psivec+min(yk-psivec,0)/gamma-g2/gamma*xik;
pk=P*(L'\((1./diag(D)).*(L\(P'*(diagM.*rhsk)))));
DJu=pk+alpha*uk; 
DJxi=pk+g2*(psivec-yk)/gamma;
