function funk=compute_Jgamma_funval(yk,uk,xik,psivec,diagM,alpha,gamma)
gk=yk-psivec;
f1=1/2*sum(gk.^2.*diagM)+alpha/2*sum(uk.^2.*diagM);
f2=sum(diagM.*(min(0,gk)).^2)/2/gamma+sum(gk.*xik.*diagM)^2/2/gamma;
funk=f1+f2;
