function yk=ALM_subsolver(K,diagM,wk,psi,rhok,yk)

ndec=size(K,1);
iter=1;
while 1
   vec=wk+rhok*(psi-yk);
   A=K+rhok*spdiags(diagM.*(vec>0),0,ndec,ndec);
   rhs=diagM.*(max(vec,0)+rhok*(vec>0).*yk);
   ykp1=A\rhs;
   residual=norm(K*ykp1-diagM.*max(wk+rhok*(psi-ykp1),0));
   if residual<=1e-6 || iter==10
       break
   end
   yk=ykp1;
   iter=iter+1;
end

