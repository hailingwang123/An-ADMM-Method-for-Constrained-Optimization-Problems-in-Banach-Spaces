% Regularized PGM for problem with complementary slackness constraints
% 2025/2/7 Revised By Hailing Wang
left=0; right=1;
bottom=0; top=1;
h=1/2^6;
Nx=(right-left)/h+1;
psi=@(x,y) max(0.1-0.5*norm([x-0.5,y-0.5]),0);
basis_type=201;
[P,T] = generate_PT(left,right,bottom,top,h,basis_type);
boundary_nodes=generate_boundarynodes(left,right,bottom,top,h,basis_type);
boundary_nodes(1,:)=[];
[coeff_ref,intpt_ref]=generate_Guass_Ref(4);
M=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,0],[0,0]);
K1=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[1,0],[1,0]);
K2=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,1],[0,1]);
K=K1+K2;
decnodes=setdiff(1:Nx^2,boundary_nodes);
Psivec=zeros(Nx^2,1);
% function psi value
for i=1:(Nx-2)^2
   veci=P(:,decnodes(i));
   Psivec(decnodes(i))=psi(veci(1),veci(2));
end
psivec=Psivec(decnodes);
[X,Y]=meshgrid(left:h:right,bottom:h:top);
figure(1)
s1=surf(X,Y,reshape(Psivec,Nx,[]));
s1.EdgeColor='none';
colormap jet
% mass lumping
diagM=M*ones(Nx^2,1);
diagM(boundary_nodes)=[];
K(boundary_nodes,:)=[]; K(:,boundary_nodes)=[];
[L,D,P]=ldl(K);
%% Step 1 -- initial guess
ndec=length(decnodes);
wk=zeros(ndec,1); rhok=1; gamma=5; tau=0.08; wmax=1e6;
yk=zeros(ndec,1);
iter_ALM=1;
while 1
   % ALM subproblem
   ykp1=ALM_subsolver(K,diagM,wk,psivec,rhok,yk);
   lambdakp1=max(wk+rhok*(psivec-ykp1),0);
   residual=max(abs(min([ykp1-psivec,lambdakp1],[],2)));
   %fprintf('This is %d ALM iteration, residual is %8.2e\n',iter_ALM,residual)
   if residual<=1e-5
      break 
   end
   Vkp1=norm(psivec-ykp1-min(psivec-ykp1+wk/rhok,0));
   if iter_ALM==1
      Vk=Vkp1;
   elseif Vkp1>tau*Vk
       rhok=rhok*gamma;
       Vk=Vkp1;
   end
   wk=min(lambdakp1,wmax); yk=ykp1; 
   iter_ALM=iter_ALM+1;
end
% Step 2 -- Regularized PGM
uk=zeros(ndec,1); xik=lambdakp1; 
yk=ykp1;
gk=yk-psivec;
alpha=1e-3;  
iter_PG=[];  
tic
tol_approx=1e-6;
print_yes=0;
if print_yes
   fprintf('\n  iter| etau    etaz    etafea|  gamma  stepk');
end
for iter_outer=1:20
   gamma=10^(-2*iter_outer);
   %beta=1/gamma;
   % using PGM approach inner subproblem P^{\gamma}
   stepsizek=1;
   [DJuk,DJxik]=compute_gradient_Jgamma(yk,uk,xik,psivec,P,L,D,diagM,alpha,gamma);
   funk=compute_Jgamma_funval(yk,uk,xik,psivec,diagM,alpha,gamma);
   for iter_inner=1:1e6
       % pgd
       [yk,uk,xik,stepsizek,DJuk,DJxik,funk]=pgd_find_step(stepsizek,yk,uk,xik,psivec,P,L,D,diagM,alpha,gamma,funk,DJuk,DJxik);
       residual=h*max(norm(uk-min(uk-DJuk,0)),norm(xik-max(xik-DJxik,0)));
       if print_yes
          fprintf('\n %5d| %2.1e| %2.1e %2.1e', ...
                 iter_inner, residual,gamma,stepsizek);
       end
       if residual<=1e-6
          iter_PG=[iter_PG,iter_inner];
          break
       end
   end
   g1k=yk-psivec; g2k=sum(-g1k.*xik.*diagM);
   dist2orgprob=max(h*norm(g1k-max(g1k,0)),abs(g2k));
   if dist2orgprob<=tol_approx
       fprintf('\n')
       break
   else
       if print_yes
           fprintf('\n  iter| etau    etaz    etafea|  gamma  stepk');
       end
   end
end
total_time=toc;
%%
%uk=min(uk,0);
disyd=h*norm(yk-psivec);
normu=h*norm(uk);
fprintf('Total Time is %8.2e\n',total_time)
fprintf('Relative distance is %8.2e\n',disyd/(h*norm(psivec)))
fprintf('The L2 norm of u is %8.2e\n',normu)
fprintf('The objective function value is %8.2e\n',1/2*disyd^2+alpha/2*normu^2)
fprintf('The complementary slackness violation is %8.2e\n',abs(sum(diagM.*(psivec-yk).*xik)))
fprintf('The feasiblility violation is %8.2e\n',h*norm(min(0,yk-psivec)))
fprintf('Total PGD iterations %d, Average PGD %8.2e, Total regularized time %d\n',sum(iter_PG),mean(iter_PG),length(iter_PG))
%% plot results

Uk=zeros(Nx^2,1); 
Uk(decnodes)=uk;
Yk=zeros(Nx^2,1);
Yk(decnodes)=yk;
Xik=zeros(Nx^2,1);
Xik(decnodes)=xik;
figure(4)
s4=surf(X,Y,reshape(Uk,[],Nx),'FaceAlpha',1);
s4.EdgeColor='none';
colormap jet
figure(5)
s5=surf(X,Y,reshape(Yk,[],Nx));
s5.EdgeColor='none';
colormap jet
figure(6)
s5=surf(X,Y,reshape(Xik,[],Nx));
s5.EdgeColor='none';
colormap jet
