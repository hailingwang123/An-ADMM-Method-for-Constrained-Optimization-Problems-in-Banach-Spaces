function [ykp1,ukp1,xikp1]=ALMOCP_solver(uk,xik,w1k,w2k,w3k,rhok,K,diagM,psivec,ndec,alpha)

options = optimoptions(@fminunc,'Display','off','Algorithm','quasi-newton','SpecifyObjectiveGradient',true);
x=fminunc(@(x) funval(x,w1k,w2k,w3k,rhok,K,diagM,psivec,alpha,ndec),[uk;xik],options);
ukp1=x(1:ndec);
xikp1=x(ndec+1:end);
ykp1=K\(diagM.*(ukp1+xikp1));
end

