function [f,g]=fungra(x,psivec,alpha,beta,beta1,lambdak,L,D,P,diagM,ndec,zk)
u=x(1:ndec);
xi=x(ndec+1:end);
y=P*(L'\((1./diag(D)).*(L\(P'*(diagM.*(u+xi))))));
rhs=y-psivec+lambdak+beta*(y-zk)-beta1*sum((psivec-y).*xi.*diagM)*xi;
p=P*(L'\((1./diag(D)).*(L\(P'*(diagM.*rhs)))));
DLubeta=p+alpha*u; DLxibeta=p+beta1*sum((psivec-y).*xi.*diagM)*(psivec-y);
g=[DLubeta.*diagM;DLxibeta.*diagM];
f1=1/2*sum((y-psivec).^2.*diagM)+alpha/2*sum(diagM.*u.^2);
f2=sum(lambdak.*y.*diagM)+beta/2*sum((y-zk).^2.*diagM)+beta1/2*(sum((y-psivec).*xi.*diagM))^2;
f=f1+f2;




