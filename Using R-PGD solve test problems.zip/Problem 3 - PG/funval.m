function [f,g]=funval(x,w1k,w2k,w3k,rhok,K,diagM,psivec,alpha,ndec)
u=x(1:ndec);
xi=x(ndec+1:end);
y=K\(diagM.*(u+xi));
f1=1/2*sum(diagM.*((y-psivec).^2))+alpha/2*sum(diagM.*(u.^2));
vec1=min(w1k+rhok*(y-psivec),0); vec2=min(w2k+rhok*xi,0);
vec3=w3k+rhok*sum((y-psivec).*diagM.*xi);
f=f1+sum(diagM.*(vec1.^2+vec2.^2))/2/rhok+vec3^2/2/rhok;
% compute gradient
p=K\(diagM.*(y-psivec+vec1+vec3*xi));
g1=diagM.*(p+alpha*u);
g2=diagM.*(p+vec3*(y-psivec)+vec2);
g=[g1;g2];

