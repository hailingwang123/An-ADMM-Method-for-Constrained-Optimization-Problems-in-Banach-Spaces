function funk=compute_Jgamma_funval(uk,psivec,diagM,K,gamma)
gk=uk-psivec;
f1=1/2*uk'*(K*uk);
f2=sum(diagM.*((min(0,gk)).^2))/2/gamma;
funk=f1+f2;
