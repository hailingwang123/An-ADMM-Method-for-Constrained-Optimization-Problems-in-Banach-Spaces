function funk=compute_Jgamma_funval(yk,uk,ydvec,ycvec,diagM,alpha,gamma)
gk=yk-ycvec;
f1=1/2*sum((yk-ydvec).^2.*diagM)+alpha/2*sum(uk.^2.*diagM);
f2=sum(diagM.*(min(0,gk)).^2)/2/gamma;
funk=f1+f2;
