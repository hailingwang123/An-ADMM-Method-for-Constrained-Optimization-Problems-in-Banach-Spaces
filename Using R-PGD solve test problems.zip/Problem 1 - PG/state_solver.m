function y=state_solver(K,diagM,u,yk,ndec)
% using Newton method
iter=0;
while 1
  ykp1=(K+spdiags(diagM.*(3*yk.^2),0,ndec,ndec))\(diagM.*u+2*diagM.*(yk.^3));
  %norm(K*ykp1+diagM.*ykp1.^3-diagM.*u)
  if norm(K*ykp1+diagM.*ykp1.^3-diagM.*u)<=1e-6 || iter==10
     break
  end
  yk=ykp1;
  iter=iter+1;
end
y=ykp1;