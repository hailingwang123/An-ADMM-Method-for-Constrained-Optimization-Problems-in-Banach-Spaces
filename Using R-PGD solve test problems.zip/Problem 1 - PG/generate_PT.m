function [P,T] = generate_PT(left,right,bottom,top,h,basis_type)

%uniform
N1=(right-left)/h;
N2=(top-bottom)/h;

if basis_type==201

P=zeros(2,(N1+1)*(N2+1));
%H �����ľ���
H=[left*ones(1,N2+1);linspace(bottom,top,N2+1)];
for i=1:N1+1
    P(:,(1:N2+1)+(i-1)*(N2+1))=H+(i-1)*[h;0];
end

T=zeros(3,2*N1*N2);
 for i=1:N1
    for j=1:N2
    T(:,2*j-1+2*N2*(i-1))=[1;N2+2;2]+[1;1;1]*(j-1)+(N2+1)*[1;1;1]*(i-1);
    T(:,2*j+2*N2*(i-1))=[2;N2+2;N2+3]+[1;1;1]*(j-1)+(N2+1)*[1;1;1]*(i-1);
    end
 end

elseif basis_type==202
    
    P=zeros(2,(2*N1+1)*(2*N2+1));
    H=[left*ones(1,2*N2+1);linspace(bottom,top,2*N2+1)];
    for i=1:2*N1+1
    P(:,(1:2*N2+1)+(i-1)*(2*N2+1))=H+(i-1)*[h;0]/2;
    end
    
    T=zeros(6,2*N1*N2);
    for i=1:N1
        for j=1:N2
             T(:,2*j-1+2*N2*(i-1))=[1;4*N2+3;3;2*N2+2;2*N2+3;2]+2*(2*N2+1)*ones(6,1)*(i-1)+2*ones(6,1)*(j-1);
             T(:,2*j+2*N2*(i-1))=[3;4*N2+3;4*N2+5;2*N2+3;4*N2+4;2*N2+4]+2*(2*N2+1)*ones(6,1)*(i-1)+2*ones(6,1)*(j-1);
        end
    end
end