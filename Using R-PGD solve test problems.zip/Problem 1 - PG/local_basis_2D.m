function result=local_basis_2D(x,y,vertices,basis_type,basis_index,basis_der_x,basis_der_y)
%vertices --��ʾ2*3����洢����

J(1,1)=vertices(1,2)-vertices(1,1);
J(1,2)=vertices(1,3)-vertices(1,1);
J(2,1)=vertices(2,2)-vertices(2,1);
J(2,2)=vertices(2,3)-vertices(2,1);
xh=((vertices(2,3)-vertices(2,1))*(x-vertices(1,1))-(vertices(1,3)-vertices(1,1))*(y-vertices(2,1)))/det(J);
yh=-((vertices(2,2)-vertices(2,1))*(x-vertices(1,1))-(vertices(1,2)-vertices(1,1))*(y-vertices(2,1)))/det(J);

if basis_der_x==0 && basis_der_y==0
    
    result=reference_basis_2D(xh,yh,basis_type,basis_index,basis_der_x,basis_der_y);

elseif basis_der_x==1 && basis_der_y==0
    
    result=reference_basis_2D(xh,yh,basis_type,basis_index,1,0)*(vertices(2,3)-vertices(2,1))/det(J)...
        +reference_basis_2D(xh,yh,basis_type,basis_index,0,1)*(vertices(2,1)-vertices(2,2))/det(J);
    
elseif basis_der_x==0 && basis_der_y==1
    
    result=reference_basis_2D(xh,yh,basis_type,basis_index,1,0)*(vertices(1,1)-vertices(1,3))/det(J)...
        +reference_basis_2D(xh,yh,basis_type,basis_index,0,1)*(vertices(1,2)-vertices(1,1))/det(J);
    
elseif basis_der_x==2 && basis_der_y==0
    
    result=reference_basis_2D(xh,yh,basis_type,basis_index,2,0)*((vertices(2,1)-vertices(2,3))/det(J))^2 ...
        +2*reference_basis_2D(xh,yh,basis_type,basis_index,1,1)*(vertices(2,3)-vertices(2,1))*(vertices(2,1)-vertices(2,2))/(det(J))^2 ...
        +reference_basis_2D(xh,yh,basis_type,basis_index,0,2)*((vertices(2,1)-vertices(2,2))/det(J))^2;
        
elseif basis_der_x==0 && basis_der_y==2
    
    result=reference_basis_2D(xh,yh,basis_type,basis_index,2,0)*((vertices(1,1)-vertices(1,3))/det(J))^2 ...
        +2*reference_basis_2D(xh,yh,basis_type,basis_index,1,1)*(vertices(1,1)-vertices(1,3))*(vertices(1,2)-vertices(1,1))/(det(J))^2 ...
        +reference_basis_2D(xh,yh,basis_type,basis_index,0,2)*((vertices(1,1)-vertices(1,2))/det(J))^2;
        
elseif basis_der_x==1 && basis_der_y==1
    
    result=reference_basis_2D(xh,yh,basis_type,basis_index,2,0)*(vertices(1,1)-vertices(1,3))*(vertices(2,3)-vertices(2,1))/(det(J))^2 ...
        +reference_basis_2D(xh,yh,basis_type,basis_index,1,1)*(vertices(1,1)-vertices(1,3))*(vertices(2,1)-vertices(2,2))/(det(J))^2 ...
        +reference_basis_2D(xh,yh,basis_type,basis_index,1,1)*(vertices(1,2)-vertices(1,1))*(vertices(2,3)-vertices(2,1))/(det(J))^2 ...
        +reference_basis_2D(xh,yh,basis_type,basis_index,0,2)*(vertices(1,2)-vertices(1,1))*(vertices(2,1)-vertices(2,2))/(det(J))^2;
 
elseif basis_der_x+basis_der_y>=3 && mod(basis_der_x,1)==0 &&  mod(basis_der_y,1)==0  
      
    result=0;
    
end