function DJuk=compute_gradient_Jgamma(yk,uk,ydvec,ycvec,K,diagM,alpha,gamma)
ndec=length(diagM);
gk=yk-ycvec;
rhs=yk-ydvec+min(gk,0)/gamma;
pk=adjoint_solver(K,diagM,yk,rhs,ndec);
DJuk=pk+alpha*uk;