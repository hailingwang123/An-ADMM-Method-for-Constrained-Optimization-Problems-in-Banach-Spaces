function DJuk=compute_gradient_Jgamma(uk,psivec,K,diagM,gamma,L,diagD,P)
rhs=K*uk+diagM.*min(uk-psivec,0)/gamma;
DJuk=P'*rhs;  
DJuk=L\DJuk;
DJuk=diagD.\DJuk;
DJuk=L'\DJuk;
DJuk=P*DJuk;