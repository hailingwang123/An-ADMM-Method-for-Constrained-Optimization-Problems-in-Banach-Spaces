function [uk,stepsizek,DJuk,funk]=pgd_find_step(stepsizek,uk,psivec,K,diagM,gamma,funk,DJuk,L,diagD,P)
% firstly compute gradient
ndec=length(diagM);
utemp=uk-stepsizek*DJuk;
funtemp=compute_Jgamma_funval(utemp,psivec,diagM,K,gamma);
flag=((funtemp-funk)<=-1e-4/stepsizek*(sum((utemp-uk).^2.*diagM)+(utemp-uk)'*(K*(utemp-uk))));
eta1=2; eta2=0.4;
if flag
   % add stepsize
   for iter=1:50
       stepsizek=stepsizek*eta1;
       utemp1=uk-stepsizek*DJuk;
       funtemp1=compute_Jgamma_funval(utemp1,psivec,diagM,K,gamma);
       if (funtemp1-funk)<=-1e-4/stepsizek*(sum((utemp1-uk).^2.*diagM)+(utemp-uk)'*(K*(utemp-uk))) 
           utemp=utemp1;
           funtemp=funtemp1;
       else
           uk=utemp;       
           funk=funtemp;
           stepsizek=stepsizek/eta1;
           break
       end
   end
else 
   % reduce stepsize 
    for iter=1:50
       stepsizek=stepsizek*eta2;
       utemp=uk-stepsizek*DJuk;
       funtemp=compute_Jgamma_funval(utemp,psivec,diagM,K,gamma);
       if ((funtemp-funk)<=-1e-4/stepsizek*(sum((utemp-uk).^2.*diagM)+(utemp-uk)'*(K*(utemp-uk)))) || (stepsizek<=1e-7)
           uk=utemp;
           funk=funtemp;
           if stepsizek<=1e-7
              stepsizek=stepsizek*eta1*1.5;
           end
           break
       end
   end 
end
DJuk=compute_gradient_Jgamma(uk,psivec,K,diagM,gamma,L,diagD,P);
%{
for iter=1:10
   utemp=min(ub,max(ua,uk-stepsizek*DJuk));
   ytemp=state_solver(K,diagM,utemp,yk,ndec);
   funtemp=compute_Jgamma_funval(ytemp,utemp,ydvec,ycvec,diagM,alpha,gamma);
   if funtemp<=funk-1e-4*sum((utemp-uk).*DJuk.*diagM)%funtemp<=funk-1e-4/stepsizek*sum((utemp-uk).^2.*diagM)
       funk=funtemp;
       yk=ytemp;
       uk=utemp;
       DJuk=compute_gradient_Jgamma(yk,uk,ydvec,ycvec,K,diagM,alpha,gamma);
       break
   else
       stepsizek=stepsizek/2;
   end
end
%}