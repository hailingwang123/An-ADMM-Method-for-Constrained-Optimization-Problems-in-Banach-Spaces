function [yk,uk,stepsizek,DJuk,funk]=pgd_find_step(stepsizek,yk,uk,ydvec,ycvec,K,diagM,alpha,gamma,ua,ub,funk,DJuk)
% firstly compute gradient
ndec=length(diagM);
utemp=min(ub,max(ua,uk-stepsizek*DJuk));
ytemp=state_solver(K,diagM,utemp,yk,ndec);
funtemp=compute_Jgamma_funval(ytemp,utemp,ydvec,ycvec,diagM,alpha,gamma);
flag=((funtemp-funk)<=-1e-4/stepsizek*sum((utemp-uk).^2.*diagM));
eta1=2; eta2=0.4;
if flag
   % add stepsize
   for iter=1:50
       stepsizek=stepsizek*eta1;
       utemp1=min(ub,max(ua,uk-stepsizek*DJuk));
       ytemp1=state_solver(K,diagM,utemp1,yk,ndec);
       funtemp1=compute_Jgamma_funval(ytemp1,utemp1,ydvec,ycvec,diagM,alpha,gamma);
       if ((funtemp1-funk)<=-1e-4/stepsizek*sum((utemp1-uk).^2.*diagM)) && stepsizek<=1e2
           utemp=utemp1;
           ytemp=ytemp1;
           funtemp=funtemp1;
       else
           yk=ytemp;
           uk=utemp;
           funk=funtemp;
           stepsizek=stepsizek/eta1;
           break
       end
   end
else 
   % reduce stepsize 
    for iter=1:50
       stepsizek=stepsizek*eta2;
       utemp=min(ub,max(ua,uk-stepsizek*DJuk));
       ytemp=state_solver(K,diagM,utemp,yk,ndec);
       funtemp=compute_Jgamma_funval(ytemp,utemp,ydvec,ycvec,diagM,alpha,gamma);
       if ((funtemp-funk)<=-1e-4/stepsizek*sum((utemp-uk).^2.*diagM)) || (stepsizek<=1e-4) || iter==50
           yk=ytemp;
           uk=utemp;
           funk=funtemp;
           if stepsizek<=1e-4
              stepsizek=stepsizek*eta1;
           end
           break
       end
   end 
end
DJuk=compute_gradient_Jgamma(yk,uk,ydvec,ycvec,K,diagM,alpha,gamma);
%{
for iter=1:10
   utemp=min(ub,max(ua,uk-stepsizek*DJuk));
   ytemp=state_solver(K,diagM,utemp,yk,ndec);
   funtemp=compute_Jgamma_funval(ytemp,utemp,ydvec,ycvec,diagM,alpha,gamma);
   if funtemp<=funk-1e-4*sum((utemp-uk).*DJuk.*diagM)%funtemp<=funk-1e-4/stepsizek*sum((utemp-uk).^2.*diagM)
       funk=funtemp;
       yk=ytemp;
       uk=utemp;
       DJuk=compute_gradient_Jgamma(yk,uk,ydvec,ycvec,K,diagM,alpha,gamma);
       break
   else
       stepsizek=stepsizek/2;
   end
end
%}