function [f,g]=fungra(u,ydvec,alpha,beta,lambdak,yk,zk,K,diagM,ndec)

y=state_solver(K,diagM,u,yk,ndec);
Lbeta1=1/2*sum((y-ydvec).^2.*diagM)+alpha/2*sum(u.^2.*diagM);
Lbeta2=sum(lambdak.*diagM.*(y-zk))+beta/2*sum((y-zk).^2.*diagM);
f=full(Lbeta1+Lbeta2);
rhsk=y-ydvec+lambdak+beta*(y-zk);
p=adjoint_solver(K,diagM,y,rhsk,ndec);
g=diagM.*(p+alpha*u);
