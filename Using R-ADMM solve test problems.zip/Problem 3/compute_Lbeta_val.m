function Lbeta=compute_Lbeta_val(yk,uk,zk,z2k,lambdak,lambda2k,gk,g2k,psivec,diagM,alpha,beta)

Lbeta1=1/2*sum((yk-psivec).^2.*diagM)+alpha/2*sum(uk.^2.*diagM);
Lbeta2=sum(lambdak.*diagM.*gk)+beta/2*sum((gk-zk).^2.*diagM)+lambda2k*(g2k-z2k)+beta/2*(g2k-z2k)^2;
Lbeta=Lbeta1+Lbeta2;
