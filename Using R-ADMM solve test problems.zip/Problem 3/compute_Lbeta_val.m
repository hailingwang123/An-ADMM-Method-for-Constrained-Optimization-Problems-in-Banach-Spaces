function Lbeta=compute_Lbeta_val(yk,uk,z1k,z2k,lambdak,lambda2k,g1k,g2k,psivec,diagM,alpha,beta)

Lbeta1=1/2*sum((yk-psivec).^2.*diagM)+alpha/2*sum(uk.^2.*diagM);
Lbeta2=sum(lambdak.*diagM.*g1k)+beta/2*sum((g1k-z1k).^2.*diagM)+lambda2k*(g2k-z2k)+beta/2*(g2k-z2k)^2;
Lbeta=Lbeta1+Lbeta2;
