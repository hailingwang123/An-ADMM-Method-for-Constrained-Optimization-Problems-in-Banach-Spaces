function [ykp1,ukp1,xikp1,stepsizek,iter]=pgd_find_step(stepsizek,yk,z1k,z2k,uk,xik,lambda1k,lambda2k,psivec,beta,diagM,alpha,P,L,D)
% firstly compute gradient
g1k=yk-psivec;
g2k=-sum(g1k.*xik.*diagM);
rhsk=yk-psivec+lambda1k-lambda2k*xik+beta*(g1k-z1k)-beta*(g2k-z2k)*xik;
pk=diagM.*rhsk;
pk=P'*pk;
pk=L\pk;
pk=diag(D).\pk;
pk=L'\pk;
pk=P*pk;
%pk=P*(L'\((1./diag(D)).*(L\(P'*(diagM.*rhsk)))));
DLbeta_u=pk+alpha*uk; 
DLbeta_xi=pk-lambda2k*g1k-beta*(g2k-z2k)*g1k;
Lbeta=compute_Lbeta_val(yk,uk,z1k,z2k,lambda1k,lambda2k,g1k,g2k,psivec,diagM,alpha,beta);
utemp=min(uk-stepsizek*DLbeta_u,0); xitemp=max(xik-stepsizek*DLbeta_xi,0);
ytemp=P*(L'\((1./diag(D)).*(L\(P'*(diagM.*(utemp+xitemp))))));
g1temp=ytemp-psivec;
g2temp=-sum(g1temp.*xitemp.*diagM);
Lbetatemp=compute_Lbeta_val(ytemp,utemp,z1k,z2k,lambda1k,lambda2k,g1temp,g2temp,psivec,diagM,alpha,beta);
flag=((Lbetatemp-Lbeta)<=-1e-4*(sum((utemp-uk).^2.*diagM)+sum((xitemp-xik).^2.*diagM)));
eta1=2; eta2=0.4;
if flag
   % add stepsize
   for iter=1:50
       stepsizek=stepsizek*eta1;
       utemp1=min(uk-stepsizek*DLbeta_u,0); xitemp1=max(xik-stepsizek*DLbeta_xi,0);
       ytemp1=P*(L'\((1./diag(D)).*(L\(P'*(diagM.*(utemp1+xitemp1))))));
       g1temp=ytemp1-psivec;
       g2temp=-sum(g1temp.*xitemp1.*diagM);
       Lbetatemp1=compute_Lbeta_val(ytemp1,utemp1,z1k,z2k,lambda1k,lambda2k,g1temp,g2temp,psivec,diagM,alpha,beta);
       %((Lbetatemp1-Lbeta)<=-1e-4*sum((utemp1-uk).^2.*diagM)) && (norm(utemp1-utemp)>1e-6)
       if ((Lbetatemp1-Lbeta)<=-1e-4*(sum((utemp1-uk).^2.*diagM)+sum((xitemp1-xik).^2.*diagM))) && stepsizek<=100 %&& (norm(utemp1-utemp)>1e-6)
           utemp=utemp1;
           xitemp=xitemp1;
           ytemp=ytemp1;
       else
           ykp1=ytemp;
           xikp1=xitemp;
           ukp1=utemp;
           stepsizek=stepsizek/eta1;
           break
       end
   end
else 
   % reduce stepsize 
    for iter=1:50
       stepsizek=stepsizek*eta2;
       utemp=min(uk-stepsizek*DLbeta_u,0); xitemp=max(xik-stepsizek*DLbeta_xi,0);
       ytemp=P*(L'\((1./diag(D)).*(L\(P'*(diagM.*(utemp+xitemp))))));
       g1temp=ytemp-psivec;
       g2temp=-sum(g1temp.*xitemp.*diagM);
       Lbetatemp=compute_Lbeta_val(ytemp,utemp,z1k,z2k,lambda1k,lambda2k,g1temp,g2temp,psivec,diagM,alpha,beta);
       if ((Lbetatemp-Lbeta)<=-1e-4*(sum((utemp-uk).^2.*diagM)+sum((xitemp-xik).^2.*diagM)))|| (stepsizek<=1e-4)
           ykp1=ytemp;
           ukp1=utemp;
           xikp1=xitemp;
           if stepsizek<=1e-4
              stepsizek=stepsizek*eta1;
           end
           break
       end
   end 
end
