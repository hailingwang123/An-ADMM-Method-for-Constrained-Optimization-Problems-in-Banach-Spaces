% ALM - Banach complementary slackness
%2025/2/7 Revised By Hailing Wang
left=0; right=1;
bottom=0; top=1;
h=1/2^6;
Nx=(right-left)/h+1;
psi=@(x,y) max(0.1-0.5*norm([x-0.5,y-0.5]),0);
basis_type=201;
[P,T] = generate_PT(left,right,bottom,top,h,basis_type);
boundary_nodes=generate_boundarynodes(left,right,bottom,top,h,basis_type);
boundary_nodes(1,:)=[];
[coeff_ref,intpt_ref]=generate_Guass_Ref(4);
M=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,0],[0,0]);
K1=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[1,0],[1,0]);
K2=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,1],[0,1]);
K=K1+K2;
decnodes=setdiff(1:Nx^2,boundary_nodes);
Psivec=zeros(Nx^2,1);
% function psi value
for i=1:(Nx-2)^2
   veci=P(:,decnodes(i));
   Psivec(decnodes(i))=psi(veci(1),veci(2));
end
psivec=Psivec(decnodes);
[X,Y]=meshgrid(left:h:right,bottom:h:top);
figure(1)
s1=surf(X,Y,reshape(Psivec,Nx,[]));
s1.EdgeColor='none';
colormap jet
% mass lumping
diagM=M*ones(Nx^2,1);
diagM(boundary_nodes)=[];
K(boundary_nodes,:)=[]; K(:,boundary_nodes)=[];
[L,D,P]=ldl(K);
%% Step 1 -- initial guess
ndec=length(decnodes);
wk=zeros(ndec,1); rhok=1; gamma=5; tau=0.08; wmax=1e6;
yk=zeros(ndec,1);
iter_ALM=1;
while 1
   % ALM subproblem
   ykp1=ALM_subsolver(K,diagM,wk,psivec,rhok,yk);
   lambdakp1=max(wk+rhok*(psivec-ykp1),0);
   residual=max(abs(min([ykp1-psivec,lambdakp1],[],2)));
   %fprintf('This is %d ALM iteration, residual is %8.2e\n',iter_ALM,residual)
   if residual<=1e-5
      yk=ykp1;
      break 
   end
   Vkp1=norm(psivec-ykp1-min(psivec-ykp1+wk/rhok,0));
   if iter_ALM==1
      Vk=Vkp1;
   elseif Vkp1>tau*Vk
       rhok=rhok*gamma;
       Vk=Vkp1;
   end
   wk=min(lambdakp1,wmax);  
   iter_ALM=iter_ALM+1;
end
% Step 2 -- ADMM
uk=zeros(ndec,1); xik=lambdakp1; 
alpha=1e-3; 
beta=1e3; 
%options = optimoptions(@fminunc,'Display','none','Algorithm','quasi-newton','SpecifyObjectiveGradient',true);
options=optimoptions('fmincon','SpecifyConstraintGradient',true,'SpecifyObjectiveGradient',true,'Display','off',...
           'Algorithm','sqp','MaxFunEvals',Inf,...
           'OptimalityTolerance',1e-4, 'StepTolerance', 1e-5,'MaxIteration',200);
%options = optimoptions(@fminunc,'Display','none','Algorithm','quasi-newton','SpecifyObjectiveGradient',true);
% options=optimoptions('fmincon','SpecifyConstraintGradient',true,'SpecifyObjectiveGradient',true,'Display','none',...
%          'Algorithm','sqp','MaxFunEvals',Inf,...
%          'OptimalityTolerance',1e-5, 'StepTolerance', 1e-5,'MaxIteration',500);
iter_ADMM=[];  
tic
tol_approx=1e-6;
linesearch_total=0;
print_yes=1;
if print_yes
   fprintf('\n  iter| etau    etaz    etafea|  gamma  stepk');
end
for iter_outer=1:20
   gamma=10^(-2*iter_outer);
   % initialize
   g1k=yk-psivec;
   g2k=-sum(g1k.*xik.*diagM);
   z1k=g1k;
   z2k=g2k;
   lambda1k=(z1k-max(z1k,0))/gamma;
   lambda2k=z2k/gamma;
   beta=sqrt(2)/gamma;
   % using ADMM approach inner subproblem P^{\gamma}
   stepsizek=1;
   for iter_inner=1:1e6
       % ADMM iteration inexact -- pg
       [ykp1,ukp1,xikp1,stepsizek,linesearch_iter]=pgd_find_step(stepsizek,yk,z1k,z2k,uk,xik,lambda1k,lambda2k,psivec,beta,diagM,alpha,P,L,D);
       linesearch_total=linesearch_total+linesearch_iter;
       % iteration 2
       g1kp1=ykp1-psivec;
       g2kp1=-sum(g1kp1.*xikp1.*diagM);
       ytemp=max(g1kp1+lambda1k/beta,0);
       z1kp1=gamma/(1+beta*gamma)*(lambda1k+beta*g1kp1+ytemp/gamma);
       z2kp1=gamma/(1+beta*gamma)*(lambda2k+beta*g2kp1);
       feasvio1=g1kp1-z1kp1;
       feasvio2=g2kp1-z2kp1;
       lambda1k=lambda1k+beta*feasvio1;
       lambda2k=lambda2k+beta*feasvio2;
       residual_uxi=max(sqrt(sum((ukp1-uk).^2.*diagM)),sqrt(sum((xikp1-xik).^2.*diagM)));
       residual_z=max(sqrt(sum((z1kp1-z1k).^2.*diagM)),sqrt(sum((z2kp1-z2k).^2.*diagM)));
       residual_feas=max(sqrt(sum(feasvio1.^2.*diagM)),abs(feasvio2));
       uk=ukp1; xik=xikp1; yk=ykp1; z1k=z1kp1; z2k=z2kp1;
       if print_yes
          fprintf('\n %5d| %2.1e %2.1e %2.1e| %2.1e %2.1e|', ...
                 iter_inner, residual_uxi,residual_z,residual_feas,gamma,stepsizek);
       end
       %funvalkp1=1/2*sum((yk-psivec).^2.*diagM)+alpha/2*sum(uk.^2.*diagM)+beta1/2*(sum((psivec-yk).*xik.*diagM))^2;
       %[residual_u,residual_z,residual_feas]
       if max([residual_uxi,residual_z,residual_feas])<=1e-6
          iter_ADMM=[iter_ADMM,iter_inner];
          break
       end
   end
   dist2orgprob=max(h*norm(z1k-max(z1k,0)),abs(z2k));
   if dist2orgprob<=tol_approx
       fprintf('\n')
       break
   else
       if print_yes
           fprintf('\n  iter| etau    etaz    etafea|  gamma  stepk');
       end
   end
end
total_time=toc;
%uk=min(uk,0);
disyd=h*norm(yk-psivec);
normu=h*norm(uk);
fprintf('Total Time is %8.2e\n',total_time)
fprintf('Relative distance is %8.2e\n',disyd/(h*norm(psivec)))
fprintf('The L2 norm of u is %8.2e\n',normu)
fprintf('The objective function value is %8.2e\n',1/2*disyd^2+alpha/2*normu^2)
fprintf('The complementary slackness violation is %8.2e\n',abs(sum(diagM.*(psivec-ykp1).*xik)))
fprintf('The feasiblility violation is %8.2e\n',h*norm(min(0,ykp1-psivec)))
fprintf('Total ADMM iterations %d, Average ADMM %8.2e, Total regularized time %d\n',sum(iter_ADMM),mean(iter_ADMM),length(iter_ADMM))
fprintf('Total line seach iterations %d\n',linesearch_total)
%% plot results
Uk=zeros(Nx^2,1); 
Uk(decnodes)=uk;
Yk=zeros(Nx^2,1);
Yk(decnodes)=ykp1;
Xik=zeros(Nx^2,1);
Xik(decnodes)=xikp1;
figure(4)
s4=surf(X,Y,reshape(Uk,[],Nx),'FaceAlpha',1);
s4.EdgeColor='none';
colormap jet
figure(5)
s5=surf(X,Y,reshape(Yk,[],Nx));
s5.EdgeColor='none';
colormap jet
figure(6)
s5=surf(X,Y,reshape(Xik,[],Nx));
s5.EdgeColor='none';
colormap jet
