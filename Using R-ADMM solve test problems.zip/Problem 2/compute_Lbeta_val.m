function Lbeta=compute_Lbeta_val(yk,zk,lambdak,gk,diagM,beta,K)

Lbeta=1/2*yk'*K*yk+sum(lambdak.*diagM.*yk)+beta/2*sum((gk-zk).^2.*diagM);
