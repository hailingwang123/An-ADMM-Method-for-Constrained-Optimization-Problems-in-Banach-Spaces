function [ykp1,stepsizek,iter]=pgd_find_step(stepsizek,yk,zk,lambdak,psivec,beta,K,diagM)
% firstly compute gradient
ndec=length(diagM);
gk=yk-psivec;
DLbeta=(K*yk+diagM.*(lambdak+beta*(gk-zk)))./diagM;
Lbeta=compute_Lbeta_val(yk,zk,lambdak,gk,diagM,beta,K);
ytemp=yk-stepsizek*DLbeta;
Lbetatemp=compute_Lbeta_val(ytemp,zk,lambdak,ytemp-psivec,diagM,beta,K);
flag=((Lbetatemp-Lbeta)<=-1e-4*sum((ytemp-yk).^2.*diagM));
eta1=2; eta2=0.4;
if flag
   % add stepsize
   for iter=1:50
       stepsizek=stepsizek*eta1;
       ytemp1=yk-stepsizek*DLbeta;
       Lbetatemp1=compute_Lbeta_val(ytemp1,zk,lambdak,ytemp1-psivec,diagM,beta,K);
       %((Lbetatemp1-Lbeta)<=-1e-4*sum((utemp1-uk).^2.*diagM)) && (norm(utemp1-utemp)>1e-6)
       if ((Lbetatemp1-Lbeta)<=-1e-4*sum((ytemp1-yk).^2.*diagM)) %&& (norm(utemp1-utemp)>1e-6)
           ytemp=ytemp1;
       else
           ykp1=ytemp;
           stepsizek=stepsizek/eta1;
           break
       end
   end
else 
   % reduce stepsize
    for iter=1:50
       stepsizek=stepsizek*eta2;
       ytemp=yk-stepsizek*DLbeta;
       Lbetatemp=compute_Lbeta_val(ytemp,zk,lambdak,ytemp-psivec,diagM,beta,K);
       if ((Lbetatemp-Lbeta)<=-1e-4*sum((ytemp-yk).^2.*diagM)) || (stepsizek<=1e-7) || iter==50
           ykp1=ytemp;
           if stepsizek<=1e-7
              stepsizek=stepsizek*eta1*1.2;
           end
           break
       end
   end 
end
