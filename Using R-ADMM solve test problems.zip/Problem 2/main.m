% ALM - Banach complementary slackness
%2023/9/12 By Hailing Wang
left=0; right=1;
bottom=0; top=1;
h=1/2^6;
Nx=(right-left)/h+1;
psi=@(x,y) max(0.1-0.5*norm([x-0.5,y-0.5]),0);
basis_type=201;
[P,T] = generate_PT(left,right,bottom,top,h,basis_type);
boundary_nodes=generate_boundarynodes(left,right,bottom,top,h,basis_type);
boundary_nodes(1,:)=[];
[coeff_ref,intpt_ref]=generate_Guass_Ref(4);
M=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,0],[0,0]);
K1=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[1,0],[1,0]);
K2=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,1],[0,1]);
K=K1+K2;
decnodes=setdiff(1:Nx^2,boundary_nodes);
Psivec=zeros(Nx^2,1);
% function psi value
for i=1:(Nx-2)^2
   veci=P(:,decnodes(i));
   Psivec(decnodes(i))=psi(veci(1),veci(2));
end
psivec=Psivec(decnodes);
[X,Y]=meshgrid(left:h:right,bottom:h:top);
figure(1)
s1=surf(X,Y,reshape(Psivec,Nx,[]));
s1.EdgeColor='none';
colormap jet
% mass lumping
diagM=M*ones(Nx^2,1);
diagM(boundary_nodes)=[];
K(boundary_nodes,:)=[]; K(:,boundary_nodes)=[];
%% ALM method -- Step 1
ndec=length(decnodes);
yk=zeros(ndec,1); 
gk=yk-psivec;
zk=zeros(ndec,1); 
lambdak=zeros(ndec,1);
beta=1e3; 
iter_ADMM=[];  
tol_approx=1e-6;
print_yes=0;
if print_yes
   fprintf('\n  iter| etau    etaz    etafea|  gamma  stepsize');
end
tic
tol_ADMM=1e-6;
linesearch_total=0;
KM=K+beta*spdiags(diagM,0,ndec,ndec);
[L,D,P]=ldl(KM);
diagD=diag(D);
for iter_outer=1:20
   gamma=10^(-2*iter_outer);
   %beta=sqrt(2)/gamma;
   % using ADMM approach inner subproblem P^{\gamma}
   stepsizek=1;
   for iter_inner=1:1e6
       % ADMM iteration inexact -- pg
       [ykp1,stepsizek,linesearch_iter]=pgd_find_step(stepsizek*1.1,yk,zk,lambdak,psivec,beta,K,diagM);
       linesearch_total=linesearch_total+linesearch_iter;
       % exact - ADMM iteration
       %rhs=diagM.*(lambdak-beta*(psivec+zk));
       %ykp1=-P*(L'\(diagD.\(L\(P'*rhs))));
       % iteration 2
       gukp1=ykp1-psivec;
       ytemp=max(gukp1+lambdak/beta,0);
       zkp1=gamma/(1+beta*gamma)*(lambdak+beta*gukp1+ytemp/gamma);
       feasvio=gukp1-zkp1;
       lambdakp1=lambdak+beta*feasvio;
       residual_y=h*norm(ykp1-yk);
       residual_z=h*norm(zkp1-zk);
       residual_feas=h*norm(feasvio);
       yk=ykp1; zk=zkp1; lambdak=lambdakp1;
       if print_yes
          fprintf('\n %5d| %2.1e %2.1e %2.1e| %2.1e| %2.1e|', ...
                 iter_inner, residual_y,residual_z,residual_feas,gamma,stepsizek);
       end
       %[residual_u,residual_z,residual_feas]
       if max([residual_y,residual_z,residual_feas])<=tol_ADMM
          iter_ADMM=[iter_ADMM,iter_inner];
          break
       end
   end
   dist2orgprob=h*norm(zk-max(zk,0));
   if dist2orgprob<=tol_approx
       fprintf('\n')
       break
   else
       if print_yes
           fprintf('\n  iter| etau    etaz    etafea|  gamma  stepsize');
       end
   end
end
total_time=toc;
fprintf('Total Time is %8.2e\n',total_time)
fprintf('The objective function value is %8.2e\n',1/2*ykp1'*K*ykp1)
fprintf('The feasibility violation is %8.2e\n',h*norm(min(ykp1-psivec,0)))
fprintf('Total ADMM iterations %d, Average ADMM %8.2e, Total regularized time %d\n',sum(iter_ADMM),mean(iter_ADMM),length(iter_ADMM))
fprintf('Total line search iteration number is %d\n',linesearch_total)
%{
ndec=length(decnodes);
wk=zeros(ndec,1); rhok=1; gamma=5; tau=0.08; wmax=1e6;
yk=zeros(ndec,1);
iter_ALM=1;
while 1
   % ALM subproblem
   ykp1=ALM_subsolver(K,diagM,wk,psivec,rhok,yk);
   lambdakp1=max(wk+rhok*(psivec-ykp1),0);
   residual=max(abs(min([ykp1-psivec,lambdakp1],[],2)));
   fprintf('This is %d ALM iteration, residual is %8.2e\n',iter_ALM,residual)
   if residual<=1e-5
      break 
   end
   Vkp1=norm(psivec-ykp1-min(psivec-ykp1+wk/rhok,0));
   if iter_ALM==1
      Vk=Vkp1;
   elseif Vkp1>tau*Vk
       rhok=rhok*gamma;
       Vk=Vkp1;
   end
   wk=min(lambdakp1,wmax); yk=ykp1; 
   iter_ALM=iter_ALM+1;
end
%}
%{
Lambdak=zeros(Nx^2,1); Yk=zeros(Nx^2,1);
Lambdak(decnodes)=-lambdakp1; Yk(decnodes)=ykp1;
figure(2)
s2=surf(X,Y,reshape(Yk,[],Nx));
s2.EdgeColor='none';
colormap jet
figure(3)
s3=surf(X,Y,reshape(Lambdak,[],Nx));
s3.EdgeColor='none';
colormap jet
%}