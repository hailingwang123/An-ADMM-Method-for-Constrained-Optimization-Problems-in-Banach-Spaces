function Lbeta=compute_Lbeta_val(uk,zk,lambdak,gk,diagM,beta,K)

Lbeta=1/2*uk'*(K*uk)+sum(lambdak.*(diagM.*uk))+beta/2*sum(((gk-zk).^2).*diagM);
