function Lbeta=compute_Lbeta_val(y,u,z,lambda,g,ydvec,diagM,alpha,beta)
Lbeta1=1/2*sum((y-ydvec).^2.*diagM)+alpha/2*sum(u.^2.*diagM);
Lbeta2=sum(lambda.*diagM.*(g-z))+beta/2*sum((g-z).^2.*diagM);
Lbeta=Lbeta1+Lbeta2;
