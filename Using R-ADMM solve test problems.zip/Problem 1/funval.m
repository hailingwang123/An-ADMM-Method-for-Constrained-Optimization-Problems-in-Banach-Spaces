function [f,g]=funval(u,alpha,rhok,ydvec,ycvec,wk,diagM,K,ndec,yk)

y=state_solver(K,diagM,u,yk,ndec);
f1=1/2*((y-ydvec).^2)'*diagM+alpha/2*(u.^2)'*diagM;
f2=rhok/2*((max(ycvec-y+wk/rhok,0)).^2)'*diagM;
f=f1+f2;
rhs=y-ydvec-max(wk+rhok*(ycvec-y),0);
p=adjoint_solver(K,diagM,y,rhs,ndec);
g=diagM.*(p+alpha*u);