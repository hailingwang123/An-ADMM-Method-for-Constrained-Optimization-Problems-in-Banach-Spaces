function boundary_nodes=generate_boundarynodes(left,right,bottom,top,h,basis_type)
%-1 --Dirichlet
%-2 --Neumann
%-3 --Robin
N1=(right-left)/h;
N2=(top-bottom)/h;

if basis_type==201
boundary_nodes=zeros(2,2*N1+2*N2);
%����߽���Ϊ Dirichlet ����
boundary_nodes(1,:)=-1;
for i=1:N1+1
    boundary_nodes(2,i)=1+(N2+1)*(i-1);
end
for i=N1+2:(N1+1)+N2
    boundary_nodes(2,i)=1+(N2+1)*N1+i-N1-1;
end
for i=(N1+1)+N2+1:(N1+1)+N2+N1
    boundary_nodes(2,i)=(N1+1)*(N2+1)-(N2+1)*(i-1-N1-N2);
end
for i=(N1+1)+N2+N1+1:2*(N1+N2)
    boundary_nodes(2,i)=N2+1-(i-(N1+1)-N2-N1);
end

%boundary_nodes(1,2:N1)=-3;
%boundary_edges(1,1:N1)=-3;

elseif basis_type==202
    
boundary_nodes=zeros(2,4*N1+4*N2);
%����߽���Ϊ Dirichlet ����
boundary_nodes(1,:)=-1;
k=2;
N1=k*N1;N2=k*N2;
for i=1:N1+1
    boundary_nodes(2,i)=1+(N2+1)*(i-1);
end
for i=N1+2:(N1+1)+N2
    boundary_nodes(2,i)=1+(N2+1)*N1+i-N1-1;
end
for i=(N1+1)+N2+1:(N1+1)+N2+N1
    boundary_nodes(2,i)=(N1+1)*(N2+1)-(N2+1)*(i-1-N1-N2);
end
for i=(N1+1)+N2+N1+1:2*(N1+N2)
    boundary_nodes(2,i)=N2+1-(i-(N1+1)-N2-N1);
end

%boundary_nodes(1,2:N1)=-3;
%boundary_edges(1,1:N1)=-3;

end
