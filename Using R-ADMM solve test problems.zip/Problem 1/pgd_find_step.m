function [ukp1,stepsizek,iter]=pgd_find_step(stepsizek,uk,zk,lambdak,psivec,beta,K,diagM,L,diagD,P)
% firstly compute gradient
ndec=length(diagM);
gk=uk-psivec;
%KM=K+spdiags(diagM,0,ndec,ndec);
rhs=K*uk+diagM.*(lambdak+beta*(gk-zk));
DLbeta=P'*rhs;   %KM\(K*yk+diagM.*(lambdak+beta*(gk-zk)))
DLbeta=L\DLbeta;
DLbeta=diagD.\DLbeta;
DLbeta=L'\DLbeta;
DLbeta=P*DLbeta;
Lbeta=compute_Lbeta_val(uk,zk,lambdak,gk,diagM,beta,K);
utemp=uk-stepsizek*DLbeta;
Lbetatemp=compute_Lbeta_val(utemp,zk,lambdak,utemp-psivec,diagM,beta,K);
flag=((Lbetatemp-Lbeta)<=-1e-4*(sum((utemp-uk).^2.*diagM)+(utemp-uk)'*(K*(utemp-uk))));
eta1=2; eta2=0.4;
if flag
   % add stepsize
   for iter=1:50
       stepsizek=stepsizek*eta1;
       utemp1=uk-stepsizek*DLbeta;
       Lbetatemp1=compute_Lbeta_val(utemp1,zk,lambdak,utemp1-psivec,diagM,beta,K);
       %((Lbetatemp1-Lbeta)<=-1e-4*sum((utemp1-uk).^2.*diagM)) && (norm(utemp1-utemp)>1e-6)
       if (Lbetatemp1-Lbeta)<=-1e-4*(sum((utemp1-uk).^2.*diagM)+(utemp1-uk)'*(K*(utemp1-uk))) %&& (norm(utemp1-utemp)>1e-6)
           utemp=utemp1;
       else
           ukp1=utemp;
           stepsizek=stepsizek/eta1;
           break
       end
       
   end
else 
   % reduce stepsize
    for iter=1:50
       stepsizek=stepsizek*eta2;
       utemp=uk-stepsizek*DLbeta;
       Lbetatemp=compute_Lbeta_val(utemp,zk,lambdak,utemp-psivec,diagM,beta,K);
       if ((Lbetatemp-Lbeta)<=-1e-4*(sum((utemp-uk).^2.*diagM)+(utemp-uk)'*(K*(utemp-uk)))) || (stepsizek<=1e-7) || iter==50
           ukp1=utemp;
           if stepsizek<=1e-7
              stepsizek=stepsizek*eta1*1.2;
           end
           break
       end
   end 
end
