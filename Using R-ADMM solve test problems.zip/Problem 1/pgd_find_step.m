function [ykp1,ukp1,stepsizek,iter]=pgd_find_step(stepsizek,yk,zk,uk,lambdak,ydvec,ycvec,beta,K,diagM,alpha,ua,ub)
% firstly compute gradient
ndec=length(diagM);
gk=yk-ycvec;
rhs=yk-ydvec+lambdak+beta*(gk-zk);
pk=adjoint_solver(K,diagM,yk,rhs,ndec);
DLbeta=pk+alpha*uk;
Lbeta=compute_Lbeta_val(yk,uk,zk,lambdak,gk,ydvec,diagM,alpha,beta);
utemp=min(ub,max(ua,uk-stepsizek*DLbeta));
ytemp=state_solver(K,diagM,utemp,yk,ndec);
Lbetatemp=compute_Lbeta_val(ytemp,utemp,zk,lambdak,ytemp-ycvec,ydvec,diagM,alpha,beta);
flag=((Lbetatemp-Lbeta)<=-1e-4*sum((utemp-uk).^2.*diagM));
eta1=2; eta2=0.4;
if flag
   % add stepsize
   for iter=1:50
       stepsizek=stepsizek*eta1;
       utemp1=min(ub,max(ua,uk-stepsizek*DLbeta));
       ytemp1=state_solver(K,diagM,utemp1,yk,ndec);
       Lbetatemp1=compute_Lbeta_val(ytemp1,utemp1,zk,lambdak,ytemp1-ycvec,ydvec,diagM,alpha,beta);
       %((Lbetatemp1-Lbeta)<=-1e-4*sum((utemp1-uk).^2.*diagM)) && (norm(utemp1-utemp)>1e-6)
       if ((Lbetatemp1-Lbeta)<=-1e-4*sum((utemp1-uk).^2.*diagM)) && stepsizek<=1e2
           utemp=utemp1;
           ytemp=ytemp1;
       else
           ykp1=ytemp;
           ukp1=utemp;
           stepsizek=stepsizek/eta1;
           break
       end
   end
else 
   % reduce stepsize 
    for iter=1:50
       stepsizek=stepsizek*eta2;
       utemp=min(ub,max(ua,uk-stepsizek*DLbeta));
       ytemp=state_solver(K,diagM,utemp,yk,ndec);
       Lbetatemp=compute_Lbeta_val(ytemp,utemp,zk,lambdak,ytemp-ycvec,ydvec,diagM,alpha,beta);
       if ((Lbetatemp-Lbeta)<=-1e-4*sum((utemp-uk).^2.*diagM)) || (stepsizek<=1e-4) || iter==50
           ykp1=ytemp;
           ukp1=utemp;
           if stepsizek<=1e-4
              stepsizek=stepsizek*eta1;
           end
           break
       end
   end 
end
