function y=ycfun(x1,x2)

y=-2/3+1/2*min([x1+x2,1+x1-x2,1-x1+x2,2-x1-x2]);
