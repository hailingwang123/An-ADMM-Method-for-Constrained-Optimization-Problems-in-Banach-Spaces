% Using regularizard-ADMM for solving optimization problem in Banach spaces
% Example 1 -- semilinear PDE optimal control problem 
left=0; right=1;
bottom=0; top=1;
h=1/2^4;
Nx=(right-left)/h+1;
ndec=(Nx-2)^2;
basis_type=201;
[P,T]=generate_PT(left,right,bottom,top,h,basis_type);
boundary_nodes=generate_boundarynodes(left,right,bottom,top,h,basis_type);
boundary_nodes(1,:)=[];
[coeff_ref,intpt_ref]=generate_Guass_Ref(4);
M=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,0],[0,0]);
K1=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[1,0],[1,0]);
K2=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,[0,1],[0,1]);
K=K1+K2;
% mass lumping technique
M=spdiags(M*ones(Nx^2,1),0,Nx^2,Nx^2);
M(boundary_nodes,:)=[]; M(:,boundary_nodes)=[];
K(boundary_nodes,:)=[]; K(:,boundary_nodes)=[];
diagM=diag(M);
% yt=state_solver(K,diagM,randn(ndec,1),zeros(ndec,1),ndec);
ydvec=-ones(ndec,1);
ycvec=zeros(Nx^2,1);
for i=1:Nx^2
   vec=P(:,i);
   ycvec(i)=ycfun(vec(1),vec(2));
end
yc=ycvec;
ycvec(boundary_nodes)=[];
% control bounds
ua=-10; ub=10;
%% regularizaed-ADMM solver
uk=zeros(ndec,1); 
lambdak=zeros(ndec,1);
yk=zeros(ndec,1); 
zk=yk-ycvec; 
alpha=1e-3; 
beta=1e3; 
%options = optimoptions(@fminunc,'Display','none','Algorithm','quasi-newton','SpecifyObjectiveGradient',true);
% options=optimoptions('fmincon','SpecifyConstraintGradient',true,'SpecifyObjectiveGradient',true,'Display','none',...
%          'Algorithm','sqp','MaxFunEvals',Inf,...
%          'OptimalityTolerance',1e-6, 'StepTolerance', 1e-6,'MaxIteration',500);
iter_ADMM=[];  
tic
tol_approx=1e-6;
linesearch_total=0;
print_yes=1;
if print_yes
   fprintf('\n  iter| etau    etaz    etafea|  gamma  stepk');
end
for iter_outer=1:20
   gamma=10^(-2*iter_outer);
   %beta=sqrt(2)/gamma;
   %beta=1/gamma;
   % using ADMM approach inner subproblem P^{\gamma}
   stepsizek=1;
   for iter_inner=1:1e6
       % ADMM iteration inexact -- pg
       [ykp1,ukp1,stepsizek,linesearch_iter]=pgd_find_step(stepsizek,yk,zk,uk,lambdak,ydvec,ycvec,beta,K,diagM,alpha,ua,ub);
       linesearch_total=linesearch_total+linesearch_iter;
       %[ukp1,~]=fmincon(@(u) fungra(u,ydvec,ycvec,alpha,beta,lambdak,yk,zk,K,diagM,ndec),uk,[],[],[],[],ua*ones(ndec,1),ub*ones(ndec,1),[],options);
       %ykp1=state_solver(K,diagM,ukp1,yk,ndec);
       % iteration 2
       gukp1=ykp1-ycvec;
       ytemp=max(gukp1+lambdak/beta,0);
       zkp1=gamma/(1+beta*gamma)*(lambdak+beta*gukp1+ytemp/gamma);
       feasvio=gukp1-zkp1;
       lambdakp1=lambdak+beta*feasvio;
       residual_u=h*norm(ukp1-uk);
       residual_z=h*norm(zkp1-zk);
       residual_feas=h*norm(feasvio);
       uk=ukp1; yk=ykp1; zk=zkp1; lambdak=lambdakp1;
       if print_yes
          fprintf('\n %5d| %2.1e %2.1e %2.1e| %2.1e %2.1e', ...
                 iter_inner, residual_u,residual_z,residual_feas,gamma,stepsizek);
       end
       %[residual_u,residual_z,residual_feas]
       if max([residual_u,residual_z,residual_feas])<=1e-6
          iter_ADMM=[iter_ADMM,iter_inner];
          break
       end
   end
   dist2orgprob=h*norm(zk-max(zk,0));
   if dist2orgprob<=tol_approx
       fprintf('\n')
       break
   else
       if print_yes
           fprintf('\n  iter| etau    etaz    etafea|  gamma  stepk');
       end
   end
end
total_time=toc;
%
disyd=h*norm(yk-ydvec);
normu=h*norm(uk);
reldis=disyd/(h*norm(ydvec));
Ju=1/2*disyd^2+alpha/2*normu^2;
feasvio=h*norm(min(yk-ycvec,0));
fprintf('Total Time is %8.2e\n',total_time)
fprintf('Relative distance is %8.2e\n',disyd/(h*norm(ydvec)))
fprintf('The L2 norm of u is %8.2e\n',normu)
fprintf('The objective function value is %8.2e\n',1/2*disyd^2+alpha/2*normu^2)
fprintf('The state constraints violation is %8.2e\n',h*norm(min(yk-ycvec,0)))
fprintf('Total ADMM iterations %d, Average ADMM %8.2e, Total regularized time %d\n',sum(iter_ADMM),mean(iter_ADMM),length(iter_ADMM))
fprintf('Total linesearch iteration number %d',linesearch_total)
%%
%save('infoADMM.mat','total_time','reldis','normu','Ju','feasvio','iter_ADMM')
%% plot results

[X,Y]=meshgrid(left:h:right,bottom:h:top);
decnodes=setdiff(1:Nx^2,boundary_nodes);
Ysol=zeros(Nx^2,1); Usol=Ysol; Lambdasol=Usol; 
Ysol(decnodes)=yk; Usol(decnodes)=uk; Lambdasol(decnodes)=-lambdak; Yc=yc; 
figure(1)
s1=surf(X,Y,reshape(Ysol,[],Nx),'FaceAlpha',0.5);
s1.EdgeColor='none';
colormap jet
colorbar
xlabel('x')
ylabel('y')
figure(2)
s2=surf(X,Y,reshape(Usol,[],Nx),'FaceAlpha',0.5);
s2.EdgeColor='none';
colormap jet
colorbar
xlabel('x')
ylabel('y')
figure(3)
s3=surf(X,Y,reshape(Lambdasol,[],Nx),'FaceAlpha',0.5);
s3.EdgeColor='none';
colormap jet
xlabel('x')
ylabel('y')
figure(4)
s4=surf(X,Y,reshape(Yc,[],Nx),'FaceAlpha',0.5);
s4.EdgeColor='none';
colormap jet
xlabel('x')
ylabel('y')


