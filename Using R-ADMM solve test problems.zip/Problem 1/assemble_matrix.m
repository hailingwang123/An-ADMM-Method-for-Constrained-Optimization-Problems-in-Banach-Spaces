function M=assemble_matrix(P,T,basis_type,coeff_ref,intpt_ref,test_der,trial_der)
n=size(P,2);
M=sparse(n,n);
number_ele=size(T,2);
for k=1:number_ele
    vecs=P(:,T(:,k));
    [coeff,intpt]=generate_int_loc(vecs,coeff_ref,intpt_ref);
    for i=1:3 % test function
       for j=1:3 % trial function
           intloc=compute_int_loc(vecs,coeff,intpt,i,j,basis_type,test_der,trial_der);
           row=T(i,k); col=T(j,k);
           M(row,col)=M(row,col)+intloc;
       end
    end
end

