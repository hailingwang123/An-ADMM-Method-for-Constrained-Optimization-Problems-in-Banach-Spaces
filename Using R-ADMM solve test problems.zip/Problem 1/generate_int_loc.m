function [coeff,intpt]=generate_int_loc(vecs,coeff_ref,intpt_ref)
T=[vecs(:,2)-vecs(:,1),vecs(:,3)-vecs(:,1)];
intpt=T*intpt_ref'+vecs(:,1);
coeff=det(T)*coeff_ref;
