function intloc=compute_int_loc(vecs,coeff,intpt,test_index,trial_index,basis_type,test_der,trial_der)
testval=zeros(4,1);
trialval=zeros(4,1);
for i=1:4
   inti=intpt(:,i);
   testval(i)=local_basis_2D(inti(1),inti(2),vecs,basis_type,test_index,test_der(1),test_der(2));
   trialval(i)=local_basis_2D(inti(1),inti(2),vecs,basis_type,trial_index,trial_der(1),trial_der(2));   
end
intloc=coeff*(testval.*trialval);
