function p=adjoint_solver(K,diagM,y,rhs,ndec)

p=(K+spdiags(diagM.*(3*y.^2),0,ndec,ndec))\(diagM.*rhs);